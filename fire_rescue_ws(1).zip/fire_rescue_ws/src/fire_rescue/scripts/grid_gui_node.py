#!/usr/bin/env python3
import rospy
import pygame
from std_msgs.msg import String

# Grid config
GRID_SIZE = 10
CELL_SIZE = 50
WIDTH = GRID_SIZE * CELL_SIZE
HEIGHT = GRID_SIZE * CELL_SIZE

# Default grid
grid = [["_" for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
mission_complete = False

def draw_grid(screen):
    screen.fill((255, 255, 255))  # White background

    print("[DEBUG] Drawing grid:")
    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            symbol = grid[row][col]
            print(symbol, end='')
            # Color map with fallback
            if symbol == "F":
                color = (255, 0, 0)
            elif symbol == "C":
                color = (0, 0, 255)
            elif symbol == "X":
                color = (128, 0, 128)
            elif symbol == "E":
                color = (255, 255, 0)
            elif symbol == "R":
                color = (0, 255, 0)
            else:
                color = (255, 255, 255)

            rect = pygame.Rect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 1)  # Black grid border
        print()  # new line after each row

    if mission_complete:
        font = pygame.font.SysFont("Arial", 24)
        text = font.render("MISSION COMPLETE ✅", True, (0, 200, 0))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))

    pygame.display.flip()

def update_grid(data):
    global grid, mission_complete
    lines = data.data.strip().split("\n")
    if not lines:
        return

    if "MISSION COMPLETE" in lines[0]:
        mission_complete = True
        return
    else:
        mission_complete = False

    grid = [list(line.strip()) for line in lines if len(line.strip()) == GRID_SIZE]

def main():
    global screen
    rospy.init_node('grid_gui_node')
    rospy.Subscriber('/grid_state', String, update_grid)

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("🔥 Fire Rescue Grid")

    rate = rospy.Rate(2)  # 2 Hz update rate

    while not rospy.is_shutdown():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                rospy.signal_shutdown("Pygame window closed")
                pygame.quit()
                return

        draw_grid(screen)
        rate.sleep()

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass

