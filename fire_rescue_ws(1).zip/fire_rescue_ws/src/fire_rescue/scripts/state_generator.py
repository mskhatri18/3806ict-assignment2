#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import json

def generate_state(data):
    sensor = json.loads(data.data)
    state = {
        "pos": sensor['robot_pos'],
        "carrying": False,
        "map": sensor['view']
    }
    pub = rospy.Publisher('/agent_input', String, queue_size=10)
    pub.publish(json.dumps(state))

def state_node():
    rospy.init_node('state_generator', anonymous=True)
    rospy.Subscriber('/sensor_data', String, generate_state)
    rospy.spin()

if __name__ == '__main__':
    state_node()

