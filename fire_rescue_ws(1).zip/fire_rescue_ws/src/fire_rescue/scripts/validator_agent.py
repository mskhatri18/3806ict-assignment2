#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

def validate(data):
    cmd = data.data
    allowed = ["up", "down", "left", "right", "pick-up", "drop-off"]
    if cmd in allowed:
        rospy.loginfo(f"[Validator] Action {cmd} accepted ✅")
    else:
        rospy.loginfo(f"[Validator] Action {cmd} ignored ❌")

def validator_node():
    rospy.init_node('validator_agent', anonymous=True)
    rospy.Subscriber('/planner_cmd', String, validate)
    rospy.spin()

if __name__ == '__main__':
    validator_node()

