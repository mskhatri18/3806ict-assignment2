#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import json

GRID_SIZE = 10
robot_pos = [1, 1]
carrying = False
rescued = 0
exit_pos = (8, 8)
grid = [['_'] * GRID_SIZE for _ in range(GRID_SIZE)]
grid[exit_pos[0]][exit_pos[1]] = 'E'

def move_robot(data):
    global robot_pos, grid, carrying, rescued

    cmd = data.data
    x, y = robot_pos

    if cmd == "up" and x > 0:
        robot_pos[0] -= 1
    elif cmd == "down" and x < GRID_SIZE - 1:
        robot_pos[0] += 1
    elif cmd == "left" and y > 0:
        robot_pos[1] -= 1
    elif cmd == "right" and y < GRID_SIZE - 1:
        robot_pos[1] += 1

    elif cmd == "pick-up":
        x, y = robot_pos
        tile = grid[x][y]
        rospy.loginfo(f"[Controller] Attempting pick-up at {robot_pos}, tile: {tile}")
        if tile == 'X':
            carrying = True
            rospy.set_param('/carrying', True)
            grid[x][y] = '_'
            rospy.loginfo(f"[Controller] ✅ Picked up civilian at {robot_pos}")
        else:
            rospy.loginfo(f"[Controller] ❌ No civilian (X) at {robot_pos}")

    elif cmd == "drop-off":
        if tuple(robot_pos) == exit_pos and carrying:
            carrying = False
            rospy.set_param('/carrying', False)
            rescued += 1
            rospy.loginfo(f"[Controller] 🛟 Rescued civilian! Total rescued: {rescued}")

            if not any('X' in row for row in grid):
                rospy.set_param('/mission_complete', True)
                rospy.loginfo("🎉 ✅ Mission complete! All civilians rescued.")
        else:
            rospy.loginfo(f"[Controller] ❌ Cannot drop-off. Carrying: {carrying}, Position: {robot_pos}")

    # Build grid for GUI/state
    display_grid = [row[:] for row in grid]
    if display_grid[robot_pos[0]][robot_pos[1]] in ['_', 'R']:
        display_grid[robot_pos[0]][robot_pos[1]] = 'R'
    display_grid[exit_pos[0]][exit_pos[1]] = 'E'

    env = {
        "grid": display_grid,
        "robot_pos": robot_pos
    }

    pub = rospy.Publisher('/env_state', String, queue_size=10)
    pub.publish(json.dumps(env))

def controller_node():
    rospy.init_node('movement_controller', anonymous=True)
    rospy.set_param('/carrying', False)
    rospy.Subscriber('/execute_cmd', String, move_robot)
    rospy.spin()

if __name__ == '__main__':
    controller_node()

