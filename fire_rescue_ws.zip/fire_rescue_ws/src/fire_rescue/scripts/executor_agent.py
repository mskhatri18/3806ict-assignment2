#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

def execute(data):
    cmd = data.data
    rospy.loginfo(f"[Executor] Executing: {cmd}")
    pub = rospy.Publisher('/execute_cmd', String, queue_size=10)
    pub.publish(cmd)

def executor_node():
    rospy.init_node('executor_agent', anonymous=True)
    rospy.Subscriber('/planner_cmd', String, execute)
    rospy.spin()

if __name__ == '__main__':
    executor_node()

