#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import json

start_delay = 5  # seconds

def manhattan(p1, p2):
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])

def find_nearest_x(grid, pos):
    min_dist = float('inf')
    nearest = None
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            if grid[i][j] == 'X':
                d = manhattan(pos, [i, j])
                if d < min_dist:
                    min_dist = d
                    nearest = [i, j]
    return nearest

planner_start = None

def plan(data):
    global planner_start
    if planner_start is None:
        planner_start = rospy.Time.now()

    # Delay before planner starts
    if (rospy.Time.now() - planner_start).to_sec() < start_delay:
        return

    state = json.loads(data.data)
    pos = state['robot_pos']
    grid = state['grid']
    carrying = rospy.get_param('/carrying', False)
    action = "stay"

    target = find_nearest_x(grid, pos) if not carrying else [8, 8]

    # ✅ Debug Logs
    rospy.loginfo(f"[Planner] Robot Position: {pos}")
    if target:
        rospy.loginfo(f"[Planner] Target Civilian (X): {target}")
    else:
        rospy.loginfo("[Planner] No civilians left to rescue.")

    if not target:
        if not rospy.has_param('/mission_complete'):
            rospy.set_param('/mission_complete', True)
            rospy.loginfo("✅ Mission complete! All civilians rescued.")
        return
    elif pos == target:
        action = "pick-up" if not carrying else "drop-off"
    else:
        if pos[0] < target[0]: action = "down"
        elif pos[0] > target[0]: action = "up"
        elif pos[1] < target[1]: action = "right"
        elif pos[1] > target[1]: action = "left"

    rospy.loginfo(f"[Planner] Decision: {action}")
    pub = rospy.Publisher('/planner_cmd', String, queue_size=10)
    pub.publish(action)

def planner_node():
    rospy.init_node('planner_agent', anonymous=True)
    rospy.Subscriber('/env_state', String, plan)
    rospy.spin()

if __name__ == '__main__':
    planner_node()

