#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import json
import time
import random

GRID_SIZE = 10
DIRECTIONS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def in_bounds(x, y):
    return 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE

def random_free_position(grid):
    while True:
        x, y = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
        if grid[x][y] == '_':
            return x, y

def publish_env_state():
    pub = rospy.Publisher('/env_state', String, queue_size=10)
    rospy.init_node('environment_node', anonymous=True)
    rate = rospy.Rate(1)

    grid = [['_'] * GRID_SIZE for _ in range(GRID_SIZE)]
    exit_pos = (8, 8)
    grid[exit_pos[0]][exit_pos[1]] = 'E'

    for _ in range(2):
        fx, fy = random_free_position(grid)
        grid[fx][fy] = 'F'

    for _ in range(3):
        cx, cy = random_free_position(grid)
        grid[cx][cy] = 'C'

    robot_pos = list(random_free_position(grid))

    fire_delay = 5  # delay before fire starts
    fire_interval = 3
    start_time = time.time()
    last_fire_time = 0

    while not rospy.is_shutdown():
        now = time.time()
        if now - start_time > fire_delay and now - last_fire_time > fire_interval:
            new_fire = []
            for i in range(GRID_SIZE):
                for j in range(GRID_SIZE):
                    if grid[i][j] == 'F':
                        for dx, dy in DIRECTIONS:
                            ni, nj = i + dx, j + dy
                            if in_bounds(ni, nj):
                                if grid[ni][nj] == 'C':
                                    grid[ni][nj] = 'X'
                                elif grid[ni][nj] == '_':
                                    new_fire.append((ni, nj))
            for x, y in new_fire:
                grid[x][y] = 'F'
            last_fire_time = now

        env = {
            "grid": grid,
            "robot_pos": robot_pos
        }

        # ✅ Log the full grid
        rospy.loginfo("🔲 Current Grid State:")
        for row in grid:
            rospy.loginfo(''.join(row))

        pub.publish(json.dumps(env))
        rate.sleep()

if __name__ == '__main__':
    try:
        publish_env_state()
    except rospy.ROSInterruptException:
        pass

