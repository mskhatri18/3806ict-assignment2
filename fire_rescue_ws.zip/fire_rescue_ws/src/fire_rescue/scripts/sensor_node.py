#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import json

def sensor_callback(data):
    env = json.loads(data.data)
    robot_pos = env['robot_pos']
    view = env['grid']

    sensor_data = {
        "robot_pos": robot_pos,
        "view": view
    }
    pub = rospy.Publisher('/sensor_data', String, queue_size=10)
    pub.publish(json.dumps(sensor_data))

def sensor_node():
    rospy.init_node('sensor_node', anonymous=True)
    rospy.Subscriber('/env_state', String, sensor_callback)
    rospy.spin()

if __name__ == '__main__':
    sensor_node()

